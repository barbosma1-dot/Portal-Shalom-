// Cloudflare Pages Function — responde em GET /api/apps-status
//
// Isso é o que roda de verdade quando o site está publicado no Cloudflare
// Pages (o "server.ts" na raiz do projeto só é usado quando você roda o
// projeto localmente com `npm run dev`, ou se um dia ele for hospedado em
// um servidor Node como o Cloud Run — o Cloudflare Pages não executa esse
// arquivo).
//
// As variáveis de ambiente (SUPABASE_URL_..., SUPABASE_SERVICE_KEY_...)
// precisam ser cadastradas no painel do Cloudflare Pages em:
// Settings > Environment variables (mesmos nomes usados no .env.example).

interface AppConfig {
  urlVar: string;
  keyVar: string;
  defaultUrl: string;
  name: string;
}

const appConfigs: Record<string, AppConfig> = {
  pashalom: { urlVar: "SUPABASE_URL_PASHALOM", keyVar: "SUPABASE_SERVICE_KEY_PASHALOM", defaultUrl: "https://pa-shalom.pages.dev", name: "PA Shalom" },
  poshalom: { urlVar: "SUPABASE_URL_POSHALOM", keyVar: "SUPABASE_SERVICE_KEY_POSHALOM", defaultUrl: "https://poshalom.pages.dev", name: "PO Shalom" },
  wopsh: { urlVar: "SUPABASE_URL_WOPSH", keyVar: "SUPABASE_SERVICE_KEY_WOPSH", defaultUrl: "https://wopsh.pages.dev", name: "WOP Shalom" },
  gestopro: { urlVar: "SUPABASE_URL_GESTOPRO", keyVar: "SUPABASE_SERVICE_KEY_GESTOPRO", defaultUrl: "https://gest-opro.pages.dev", name: "Gestão Pro" },
  evansh: { urlVar: "SUPABASE_URL_EVANSH", keyVar: "SUPABASE_SERVICE_KEY_EVANSH", defaultUrl: "https://evansh.pages.dev", name: "Evangelização Shalom" },
  adoracaoshalom: { urlVar: "SUPABASE_URL_ADORACOOSHALOM", keyVar: "SUPABASE_SERVICE_KEY_ADORACOOSHALOM", defaultUrl: "https://adora-o-shalom.pages.dev", name: "Adoração Shalom" },
  cifrash: { urlVar: "SUPABASE_URL_CIFRASH", keyVar: "SUPABASE_SERVICE_KEY_CIFRASH", defaultUrl: "https://cifras-sh.pages.dev", name: "Cifras Shalom" },
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export const onRequestGet: any = async (context: any) => {
  try {
    const env = context.env || {};
    const apps = Object.entries(appConfigs).map(([id, config]) => {
      const url = env[config.urlVar];
      const key = env[config.keyVar];
      return {
        id,
        name: config.name,
        url: config.defaultUrl,
        hasKeys: Boolean(url && key),
      };
    });
    return json({ apps });
  } catch (err: any) {
    return json({ error: "Erro ao listar status dos aplicativos: " + err.message }, 500);
  }
};
