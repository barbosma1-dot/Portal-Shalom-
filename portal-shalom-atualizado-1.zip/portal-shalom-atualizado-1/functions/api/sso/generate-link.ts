// Cloudflare Pages Function — responde em POST /api/sso/generate-link
//
// Equivalente ao endpoint do server.ts, mas é isso que roda de verdade
// quando o site está publicado no Cloudflare Pages. Ver comentário em
// functions/api/apps-status.ts para mais detalhes sobre por quê.

import { createClient } from "@supabase/supabase-js";

interface AppConfig {
  urlVar: string;
  keyVar: string;
  defaultUrl: string;
}

const appConfigs: Record<string, AppConfig> = {
  pashalom: { urlVar: "SUPABASE_URL_PASHALOM", keyVar: "SUPABASE_SERVICE_KEY_PASHALOM", defaultUrl: "https://pa-shalom.pages.dev" },
  poshalom: { urlVar: "SUPABASE_URL_POSHALOM", keyVar: "SUPABASE_SERVICE_KEY_POSHALOM", defaultUrl: "https://poshalom.pages.dev" },
  wopsh: { urlVar: "SUPABASE_URL_WOPSH", keyVar: "SUPABASE_SERVICE_KEY_WOPSH", defaultUrl: "https://wopsh.pages.dev" },
  gestopro: { urlVar: "SUPABASE_URL_GESTOPRO", keyVar: "SUPABASE_SERVICE_KEY_GESTOPRO", defaultUrl: "https://gest-opro.pages.dev" },
  evansh: { urlVar: "SUPABASE_URL_EVANSH", keyVar: "SUPABASE_SERVICE_KEY_EVANSH", defaultUrl: "https://evansh.pages.dev" },
  adoracaoshalom: { urlVar: "SUPABASE_URL_ADORACOOSHALOM", keyVar: "SUPABASE_SERVICE_KEY_ADORACOOSHALOM", defaultUrl: "https://adora-o-shalom.pages.dev" },
  cifrash: { urlVar: "SUPABASE_URL_CIFRASH", keyVar: "SUPABASE_SERVICE_KEY_CIFRASH", defaultUrl: "https://cifras-sh.pages.dev" },
};

// Mesma lista de autorização usada em src/lib/authorization.ts e server.ts.
// Se você editar uma, edite as três (ver instruções que o Claude te mandou).
const AUTHORIZED_ACCESS: Record<string, "all" | string[]> = {
  "barbosma1@gmail.com": "all",
};

function isEmailAuthorizedForApp(email: string | undefined | null, appId: string): boolean {
  const normalized = (email || "").trim().toLowerCase();
  if (!normalized) return false;
  const access = AUTHORIZED_ACCESS[normalized];
  if (!access) return false;
  if (access === "all") return true;
  return access.includes(appId);
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export const onRequestPost: any = async (context: any) => {
  try {
    const env = context.env || {};
    const request: Request = context.request;

    const authHeader = request.headers.get("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return json({ error: "Sessão inválida ou não fornecida. Por favor, faça login novamente." }, 401);
    }
    const token = authHeader.split(" ")[1];

    const body = await request.json().catch(() => ({}));
    const appId = (body as any)?.appId;
    if (!appId) {
      return json({ error: "O ID do aplicativo é obrigatório." }, 400);
    }

    const config = appConfigs[appId];
    if (!config) {
      return json({ error: "Aplicativo não encontrado." }, 404);
    }

    const targetUrl = env[config.urlVar];
    const targetServiceKey = env[config.keyVar];
    if (!targetUrl || !targetServiceKey) {
      return json({ error: `Este aplicativo (${appId}) ainda não está conectado no Portal Shalom.` }, 400);
    }

    const portalUrl = env.VITE_SUPABASE_URL;
    const portalAnonKey = env.VITE_SUPABASE_ANON_KEY;
    if (!portalUrl || !portalAnonKey) {
      return json({ error: "O Portal Shalom não está totalmente configurado. Chaves do Portal ausentes no servidor." }, 500);
    }

    // Verifica o JWT do usuário junto ao Supabase do Portal
    const portalClient = createClient(portalUrl, portalAnonKey);
    const { data: { user }, error: authError } = await portalClient.auth.getUser(token);
    if (authError || !user || !user.email) {
      return json({ error: "Usuário não autenticado ou sessão expirada no Portal Shalom." }, 401);
    }

    // Barreira de autorização real — não pode ser burlada pelo navegador
    if (!isEmailAuthorizedForApp(user.email, appId)) {
      return json({ error: "Este email não está autorizado a acessar este aplicativo." }, 403);
    }

    // Gera o magic link no Supabase do app de destino usando a Service Role Key
    const targetSupabase = createClient(targetUrl, targetServiceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { data: linkData, error: linkError } = await targetSupabase.auth.admin.generateLink({
      type: "magiclink",
      email: user.email,
      options: { redirectTo: config.defaultUrl },
    });

    if (linkError || !linkData) {
      return json({ error: `Não foi possível gerar acesso ao aplicativo: ${linkError?.message || "Erro desconhecido"}` }, 500);
    }

    const actionLink = (linkData as any).properties?.action_link || (linkData as any).action_link;
    if (!actionLink) {
      return json({ error: "O link de login gerado é inválido." }, 500);
    }

    return json({ actionLink });
  } catch (err: any) {
    return json({ error: `Erro interno no servidor: ${err.message}` }, 500);
  }
};
