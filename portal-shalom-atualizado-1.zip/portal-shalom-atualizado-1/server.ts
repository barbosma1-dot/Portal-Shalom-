// ATENÇÃO: este arquivo NÃO é executado quando o projeto está publicado no
// Cloudflare Pages — o Pages não roda servidores Node/Express (app.listen).
// Ele serve para rodar o projeto localmente (`npm run dev`) ou caso um dia
// você hospede em um servidor Node tradicional (ex: Google Cloud Run).
//
// Em produção no Cloudflare Pages, quem responde as rotas /api/* são as
// Functions em functions/api/apps-status.ts e functions/api/sso/generate-link.ts.
// Se você mudar algo aqui (ex: a lista de emails autorizados), replique a
// mudança nesses dois arquivos também.
import express from "express";
import path from "path";
import dotenv from "dotenv";
import { createClient } from "@supabase/supabase-js";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const PORT = 3000;

// Configuration mapping for target community apps
const appConfigs: Record<string, { urlVar: string; keyVar: string; defaultUrl: string }> = {
  pashalom: {
    urlVar: "SUPABASE_URL_PASHALOM",
    keyVar: "SUPABASE_SERVICE_KEY_PASHALOM",
    defaultUrl: "https://pa-shalom.pages.dev"
  },
  poshalom: {
    urlVar: "SUPABASE_URL_POSHALOM",
    keyVar: "SUPABASE_SERVICE_KEY_POSHALOM",
    defaultUrl: "https://poshalom.pages.dev"
  },
  wopsh: {
    urlVar: "SUPABASE_URL_WOPSH",
    keyVar: "SUPABASE_SERVICE_KEY_WOPSH",
    defaultUrl: "https://wopsh.pages.dev"
  },
  gestopro: {
    urlVar: "SUPABASE_URL_GESTOPRO",
    keyVar: "SUPABASE_SERVICE_KEY_GESTOPRO",
    defaultUrl: "https://gest-opro.pages.dev"
  },
  evansh: {
    urlVar: "SUPABASE_URL_EVANSH",
    keyVar: "SUPABASE_SERVICE_KEY_EVANSH",
    defaultUrl: "https://evansh.pages.dev"
  },
  adoracaoshalom: {
    urlVar: "SUPABASE_URL_ADORACOOSHALOM",
    keyVar: "SUPABASE_SERVICE_KEY_ADORACOOSHALOM",
    defaultUrl: "https://adora-o-shalom.pages.dev"
  },
  cifrash: {
    urlVar: "SUPABASE_URL_CIFRASH",
    keyVar: "SUPABASE_SERVICE_KEY_CIFRASH",
    defaultUrl: "https://cifras-sh.pages.dev"
  }
};

// Central authorization mapping: mirrors src/lib/authorization.ts.
// Only emails listed here can have a real SSO magic link generated for them.
// Use "all" to authorize every app, or an array of specific app ids.
const AUTHORIZED_ACCESS: Record<string, "all" | string[]> = {
  "barbosma1@gmail.com": "all",
};

function isEmailAuthorizedForApp(email: string | undefined | null, appId: string): boolean {
  const normalized = (email || "").trim().toLowerCase();
  if (!normalized) return false;
  const access = AUTHORIZED_ACCESS[normalized];
  if (!access) return false;
  if (access === "all") return true;
  return access.includes(appId);
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // API Route: Get the configuration status of all community apps
  app.get("/api/apps-status", (req, res) => {
    try {
      const status = Object.entries(appConfigs).map(([id, config]) => {
        const url = process.env[config.urlVar];
        const key = process.env[config.keyVar];
        return {
          id,
          name: id === "pashalom" ? "PA Shalom" :
                id === "poshalom" ? "PO Shalom" :
                id === "wopsh" ? "WOP Shalom" :
                id === "gestopro" ? "Gestão Pro" :
                id === "evansh" ? "Evangelização Shalom" :
                id === "adoracaoshalom" ? "Adoração Shalom" :
                id === "cifrash" ? "Cifras Shalom" : id,
          url: config.defaultUrl,
          hasKeys: Boolean(url && key)
        };
      });
      res.json({ apps: status });
    } catch (err: any) {
      res.status(500).json({ error: "Erro ao listar status dos aplicativos: " + err.message });
    }
  });

  // API Route: Securely generate an SSO Magic Link for a target community app
  app.post("/api/sso/generate-link", async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return res.status(401).json({ error: "Sessão inválida ou não fornecida. Por favor, faça login novamente." });
      }
      const token = authHeader.split(" ")[1];

      const { appId } = req.body;
      if (!appId) {
        return res.status(400).json({ error: "O ID do aplicativo é obrigatório." });
      }

      const config = appConfigs[appId];
      if (!config) {
        return res.status(404).json({ error: "Aplicativo não encontrado." });
      }

      const targetUrl = process.env[config.urlVar];
      const targetServiceKey = process.env[config.keyVar];

      if (!targetUrl || !targetServiceKey) {
        return res.status(400).json({ error: `Este aplicativo (${appId}) ainda não está conectado no Portal Shalom.` });
      }

      // Main Portal Supabase configuration (lazy validation)
      const portalUrl = process.env.VITE_SUPABASE_URL;
      const portalAnonKey = process.env.VITE_SUPABASE_ANON_KEY;

      if (!portalUrl || !portalAnonKey) {
        return res.status(500).json({ error: "O Portal Shalom não está totalmente configurado. Chaves do Portal ausentes no servidor." });
      }

      // Initialize Portal Supabase client to securely verify the active user's JWT
      const portalClient = createClient(portalUrl, portalAnonKey);
      const { data: { user }, error: authError } = await portalClient.auth.getUser(token);

      if (authError || !user || !user.email) {
        return res.status(401).json({ error: "Usuário não autenticado ou sessão expirada no Portal Shalom." });
      }

      // Authorization gate: only emails explicitly listed in AUTHORIZED_ACCESS
      // can have a real magic link generated, and only for apps they were
      // granted. This is the real security boundary — the frontend check
      // exists only for UX, this one cannot be bypassed by the browser.
      if (!isEmailAuthorizedForApp(user.email, appId)) {
        return res.status(403).json({ error: "Este email não está autorizado a acessar este aplicativo." });
      }

      // Initialize Target App's Supabase with its Service Role Key
      const targetSupabase = createClient(targetUrl, targetServiceKey, {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      });

      // Generate a magiclink login link for the user's verified email
      const { data: linkData, error: linkError } = await targetSupabase.auth.admin.generateLink({
        type: "magiclink",
        email: user.email,
        options: {
          redirectTo: config.defaultUrl
        }
      });

      if (linkError || !linkData) {
        console.error(`Erro ao gerar link para ${appId}:`, linkError);
        return res.status(500).json({ error: `Não foi possível gerar acesso ao aplicativo: ${linkError?.message || "Erro desconhecido"}` });
      }

      // Handle properties.action_link or flat action_link
      const actionLink = linkData.properties?.action_link || (linkData as any).action_link;
      if (!actionLink) {
        return res.status(500).json({ error: "O link de login gerado é inválido." });
      }

      res.json({ actionLink });
    } catch (err: any) {
      console.error("Erro interno no SSO:", err);
      res.status(500).json({ error: `Erro interno no servidor: ${err.message}` });
    }
  });

  // Vite development middleware or static production delivery
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Portal Shalom Backend] Servidor rodando em http://0.0.0.0:${PORT}`);
  });
}

startServer();
