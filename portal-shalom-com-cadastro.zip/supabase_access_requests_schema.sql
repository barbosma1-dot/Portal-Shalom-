-- Tabela para armazenar solicitações de cadastro/acesso feitas por quem ainda não está autorizado
CREATE TABLE IF NOT EXISTS access_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    app_id VARCHAR(100),
    message TEXT,
    status VARCHAR(20) DEFAULT 'pending', -- pending | approved | rejected
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    reviewed_at TIMESTAMP WITH TIME ZONE,
    reviewed_by VARCHAR(255)
);

-- Row Level Security (RLS)
ALTER TABLE access_requests ENABLE ROW LEVEL SECURITY;

-- Observação: o backend usa a Service Role Key, que ignora RLS.
-- Ainda assim, mantemos RLS ativo e sem policy pública de leitura/escrita,
-- pois todo o acesso a esta tabela deve passar pelas funções da API (/api/request-access e /api/admin/access-requests).

CREATE INDEX IF NOT EXISTS idx_access_requests_status ON access_requests (status);
CREATE INDEX IF NOT EXISTS idx_access_requests_email ON access_requests (email);
