import { getPortalClient, jsonResponse, handleOptions } from "./_shared";

export const onRequestOptions = handleOptions;

// POST: qualquer visitante (não logado ou logado sem autorização) pode enviar um pedido de cadastro/acesso
export const onRequestPost: PagesFunction<any> = async (context) => {
  try {
    let body: any;
    try {
      body = await context.request.json();
    } catch {
      return jsonResponse({ error: "Corpo da requisição inválido." }, 400);
    }

    const { name, email, appId, message } = body;

    if (!name || !email) {
      return jsonResponse({ error: "Nome e e-mail são obrigatórios." }, 400);
    }

    const normalizedEmail = String(email).toLowerCase().trim();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(normalizedEmail)) {
      return jsonResponse({ error: "Informe um e-mail válido." }, 400);
    }

    const portalClient = getPortalClient(context.env);

    const { data, error } = await portalClient
      .from("access_requests")
      .insert([
        {
          name: String(name).trim(),
          email: normalizedEmail,
          app_id: appId || null,
          message: message ? String(message).trim() : null,
          status: "pending"
        }
      ])
      .select();

    if (error) {
      if (error.code === "PGRST116" || error.message.includes("does not exist")) {
        return jsonResponse({
          error: "A tabela access_requests ainda não existe no Supabase. Peça ao administrador para rodar o script SQL de configuração."
        }, 500);
      }
      return jsonResponse({ error: "Erro ao enviar solicitação: " + error.message }, 500);
    }

    return jsonResponse({ success: true, request: data?.[0] });
  } catch (err: any) {
    return jsonResponse({ error: "Erro interno: " + err.message }, 500);
  }
};
