import { getPortalClient, getUserEmailFromRequest, jsonResponse, handleOptions, isAdminEmail } from "../_shared";

export const onRequestOptions = handleOptions;

// GET: lista todas as solicitações de cadastro/acesso (somente admin)
export const onRequestGet: PagesFunction<any> = async (context) => {
  try {
    const userEmail = await getUserEmailFromRequest(context.env, context.request);
    if (!userEmail || !(await isAdminEmail(context.env, userEmail))) {
      return jsonResponse({ error: "Acesso negado. Apenas administradores do Portal podem ver solicitações." }, 403);
    }

    const portalClient = getPortalClient(context.env);
    const { data, error } = await portalClient
      .from("access_requests")
      .select("*")
      .order("created_at", { ascending: false });

    if (error) {
      if (error.code === "PGRST116" || error.message.includes("does not exist")) {
        return jsonResponse({
          requests: [],
          warning: "A tabela access_requests não existe ainda no Supabase. Execute o script SQL para criá-la."
        });
      }
      return jsonResponse({ error: "Erro ao buscar solicitações: " + error.message }, 500);
    }

    return jsonResponse({ requests: data || [] });
  } catch (err: any) {
    return jsonResponse({ error: "Erro interno: " + err.message }, 500);
  }
};

// POST: aprova ou rejeita uma solicitação. Body: { id, action: "approve" | "reject" }
// Ao aprovar, também cria a autorização de acesso ao app escolhido (se houver).
export const onRequestPost: PagesFunction<any> = async (context) => {
  try {
    const userEmail = await getUserEmailFromRequest(context.env, context.request);
    if (!userEmail || !(await isAdminEmail(context.env, userEmail))) {
      return jsonResponse({ error: "Acesso negado. Apenas administradores do Portal podem revisar solicitações." }, 403);
    }

    let body: any;
    try {
      body = await context.request.json();
    } catch {
      return jsonResponse({ error: "Corpo da requisição inválido." }, 400);
    }

    const { id, action } = body;
    if (!id || !["approve", "reject"].includes(action)) {
      return jsonResponse({ error: "Informe o ID da solicitação e a ação ('approve' ou 'reject')." }, 400);
    }

    const portalClient = getPortalClient(context.env);

    const { data: reqRow, error: findError } = await portalClient
      .from("access_requests")
      .select("*")
      .eq("id", id)
      .single();

    if (findError || !reqRow) {
      return jsonResponse({ error: "Solicitação não encontrada." }, 404);
    }

    if (action === "approve" && reqRow.app_id) {
      const { error: authError } = await portalClient
        .from("app_authorizations")
        .insert([{ email: reqRow.email, app_id: reqRow.app_id }]);
      // Ignora erro de duplicidade (já autorizado); reporta outros erros
      if (authError && !authError.message.includes("duplicate")) {
        return jsonResponse({ error: "Erro ao criar autorização: " + authError.message }, 500);
      }
    }

    const { error: updateError } = await portalClient
      .from("access_requests")
      .update({
        status: action === "approve" ? "approved" : "rejected",
        reviewed_at: new Date().toISOString(),
        reviewed_by: userEmail
      })
      .eq("id", id);

    if (updateError) {
      return jsonResponse({ error: "Erro ao atualizar solicitação: " + updateError.message }, 500);
    }

    return jsonResponse({ success: true });
  } catch (err: any) {
    return jsonResponse({ error: "Erro interno: " + err.message }, 500);
  }
};
