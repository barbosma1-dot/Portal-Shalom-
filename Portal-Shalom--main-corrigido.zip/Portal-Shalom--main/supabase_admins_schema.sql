-- ============================================================
-- Portal Shalom - Tabela de Administradores do Portal
-- ============================================================
-- Esta tabela é a ÚNICA fonte de verdade sobre quem tem acesso
-- ao Painel Administrativo do Portal. Todo o acesso de leitura e
-- escrita passa exclusivamente pelos endpoints /api/admin/admins
-- (server.ts e functions/api/admin/admins.ts), que usam a
-- service role key no backend. Por isso, nenhuma política de
-- acesso público (RLS policy) é criada: com RLS habilitado e
-- nenhuma política definida, o acesso via chave anônima/pública
-- fica bloqueado por padrão, e apenas a service role (que
-- ignora RLS) consegue ler/escrever.

create table if not exists portal_admins (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  added_by text,
  created_at timestamptz not null default now()
);

-- Semente inicial: mantém o administrador atual com acesso garantido
insert into portal_admins (email, added_by)
values ('barbosma1@gmail.com', 'sistema')
on conflict (email) do nothing;

alter table portal_admins enable row level security;

-- Nenhuma política de acesso público é criada de propósito.
-- Apenas o backend (service role key), que ignora RLS, deve
-- ler/escrever nesta tabela. Todo acesso do frontend passa
-- pelos endpoints /api/admin/admins e /api/admin/whoami.
