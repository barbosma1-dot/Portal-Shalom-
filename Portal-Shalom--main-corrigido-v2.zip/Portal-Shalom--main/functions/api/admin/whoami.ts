import { getUserEmailFromRequestVerbose, jsonResponse, handleOptions, isAdminEmail, hasServiceRole } from "../_shared";

export const onRequestOptions = handleOptions;

export const onRequestGet: PagesFunction<any> = async (context) => {
  try {
    const { email: userEmail, reason } = await getUserEmailFromRequestVerbose(context.env, context.request);
    if (!userEmail) {
      return jsonResponse({
        isAdmin: false,
        email: null,
        detail: reason,
        hasServiceRole: hasServiceRole(context.env)
      });
    }
    const isAd = await isAdminEmail(context.env, userEmail);
    return jsonResponse({
      isAdmin: isAd,
      email: userEmail,
      hasServiceRole: hasServiceRole(context.env)
    });
  } catch (err: any) {
    return jsonResponse({ error: "Erro interno: " + err.message }, 500);
  }
};
