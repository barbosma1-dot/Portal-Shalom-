-- ============================================================
-- Portal Shalom - Tabela de Autorizações de Aplicativos (SSO ACL)
-- ============================================================
-- Esta tabela é a fonte de verdade sobre quais e-mails têm
-- permissão para acessar cada um dos aplicativos integrados do
-- Portal (PA Shalom, PO Shalom, Gestão Pro, Evangelização Shalom,
-- Adoração Shalom, Cifras Shalom, WOP Shalom).
--
-- Ela NÃO EXISTIA no banco — por isso o painel "Controle de
-- Acesso SSO (ACL)" não funcionava: o backend tentava ler/gravar
-- nesta tabela e ela nunca havia sido criada.
--
-- Assim como portal_admins, todo o acesso de leitura e escrita
-- passa exclusivamente pelos endpoints /api/admin/authorizations
-- e /api/apps-status (que usam a service role key no backend).
-- Por isso nenhuma política de acesso público (RLS policy) é
-- criada: com RLS habilitado e nenhuma política definida, o
-- acesso via chave anônima/pública fica bloqueado por padrão, e
-- apenas a service role (que ignora RLS) consegue ler/escrever.

create table if not exists app_authorizations (
  id uuid primary key default gen_random_uuid(),
  email text not null,
  app_id text not null,
  created_at timestamptz not null default now(),
  constraint app_authorizations_email_app_unique unique (email, app_id)
);

create index if not exists idx_app_authorizations_email on app_authorizations (email);
create index if not exists idx_app_authorizations_app_id on app_authorizations (app_id);

alter table app_authorizations enable row level security;

-- Nenhuma política de acesso público é criada de propósito.
-- Apenas o backend (service role key), que ignora RLS, deve
-- ler/escrever nesta tabela. Todo acesso do frontend passa pelos
-- endpoints /api/admin/authorizations e /api/apps-status.

-- Semente inicial: garante que o administrador principal continue
-- com acesso a todos os 7 aplicativos integrados mesmo antes de
-- qualquer autorização manual ser cadastrada pelo painel.
insert into app_authorizations (email, app_id) values
  ('barbosma1@gmail.com', 'pashalom'),
  ('barbosma1@gmail.com', 'poshalom'),
  ('barbosma1@gmail.com', 'gestopro'),
  ('barbosma1@gmail.com', 'evansh'),
  ('barbosma1@gmail.com', 'adoracaoshalom'),
  ('barbosma1@gmail.com', 'cifrash'),
  ('barbosma1@gmail.com', 'wopsh')
on conflict (email, app_id) do nothing;
